import { Header } from "@/app/components/Header";
import { HeroSection } from "@/app/components/HeroSection";
import { AboutSection } from "@/app/components/AboutSection";
import { ProgramsSection } from "@/app/components/ProgramsSection";
import { WorkProcessSection } from "@/app/components/WorkProcessSection";
import { TestimonialsSection } from "@/app/components/TestimonialsSection";
import { Footer } from "@/app/components/Footer";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <HeroSection />
        <AboutSection />
        <ProgramsSection />
        <WorkProcessSection />
        <TestimonialsSection />
      </main>
      <Footer />
    </div>
  );
}