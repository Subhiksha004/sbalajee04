import { 
  MessageCircle, 
  CheckCircle, 
  FileCheck, 
  Users, 
  Bell, 
  FileText, 
  Award 
} from "lucide-react";

export function WorkProcessSection() {
  const processSteps = [
    {
      icon: MessageCircle,
      title: "Detailed Counseling & Course Guidance",
      description: "Personalized counseling sessions to understand your academic goals and recommend the best-fit programs for your career aspirations."
    },
    {
      icon: CheckCircle,
      title: "University Approvals & Program Information",
      description: "Complete information about approved programs, eligibility criteria, fee structure, and course duration from partnered universities."
    },
    {
      icon: FileCheck,
      title: "Smooth Application & Admission Process",
      description: "End-to-end support for application submission, documentation, and admission formalities with minimal hassle."
    },
    {
      icon: Users,
      title: "Document Verification & Enrollment Support",
      description: "Thorough document verification process and enrollment assistance to ensure your admission is processed correctly."
    },
    {
      icon: Bell,
      title: "Regular Updates to Agents and Students",
      description: "Consistent communication and status updates throughout the admission process to keep everyone informed."
    },
    {
      icon: FileText,
      title: "Assistance with Marks Cards & Transcripts",
      description: "Support for obtaining marks cards, transcripts, grade sheets, and other academic documents as needed."
    },
    {
      icon: Award,
      title: "Convocation Guidance & Continued Support",
      description: "Complete guidance for convocation ceremonies and ongoing support until successful course completion."
    }
  ];

  return (
    <section id="process" className="py-16 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Our Work Process</h2>
          <div className="w-24 h-1 bg-blue-700 mx-auto mb-6"></div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            A comprehensive, student-first approach ensuring a smooth journey from application to graduation
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {processSteps.map((step, index) => (
            <div
              key={index}
              className="relative bg-gradient-to-br from-blue-50 to-white p-6 rounded-lg shadow-md hover:shadow-xl transition duration-300 border border-blue-100"
            >
              <div className="absolute -top-4 -left-4 bg-blue-700 text-white w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg shadow-lg">
                {index + 1}
              </div>
              <div className="mt-2">
                <step.icon className="w-10 h-10 text-blue-700 mb-4" />
                <h3 className="text-xl font-bold text-gray-900 mb-3">{step.title}</h3>
                <p className="text-gray-600 leading-relaxed">{step.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="mt-16 bg-gradient-to-r from-blue-700 to-blue-900 text-white p-8 sm:p-12 rounded-lg shadow-xl text-center">
          <h3 className="text-2xl sm:text-3xl font-bold mb-4">Ready to Begin Your Educational Journey?</h3>
          <p className="text-lg text-blue-100 mb-6 max-w-2xl mx-auto">
            Contact us today for free counseling and personalized guidance. Our team is here to help you every step of the way.
          </p>
          <button
            onClick={() => document.getElementById("home")?.scrollIntoView({ behavior: "smooth" })}
            className="bg-white text-blue-800 px-8 py-3 rounded-lg font-bold hover:bg-blue-50 transition duration-300 shadow-lg hover:shadow-xl"
          >
            Get Started Now
          </button>
        </div>
      </div>
    </section>
  );
}
