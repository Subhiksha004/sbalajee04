import { BookOpen, Target, Users, Award } from "lucide-react";

export function AboutSection() {
  return (
    <section id="about" className="py-16 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">About Us</h2>
          <div className="w-24 h-1 bg-blue-700 mx-auto"></div>
        </div>

        <div className="grid md:grid-cols-2 gap-8 lg:gap-12 items-center mb-12">
          <div>
            <p className="text-lg text-gray-700 leading-relaxed mb-4">
              <strong className="text-blue-800">Sree Balajee Scholars Hub</strong> is a trusted education consultancy dedicated to guiding students towards the right academic and career opportunities. Established under <strong>Sree Balaji Educational Charitable Trust</strong>, our mission is to support learners in achieving quality education through transparent guidance, reliable admissions support, and continuous mentorship.
            </p>
            <p className="text-lg text-gray-700 leading-relaxed mb-4">
              We proudly collaborate with reputed universities such as <strong>Nagarjuna University</strong>, offering a wide range of UG, PG, Diploma, Technical, and Professional programs. With strong university partnerships and a student-first work process, we ensure a smooth admission experience from counseling to enrollment.
            </p>
            <p className="text-lg text-gray-700 leading-relaxed">
              Our dedicated team works closely with students, parents, and agents to provide personalized support, helping them choose courses that best match their goals. We also ensure timely document processing, verification, and post-admission services such as marks cards, transcripts, convocation guidance, and more.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-6">
            <div className="bg-blue-50 p-6 rounded-lg text-center hover:shadow-lg transition">
              <BookOpen className="w-12 h-12 text-blue-700 mx-auto mb-3" />
              <h3 className="font-bold text-gray-900 mb-2">Quality Education</h3>
              <p className="text-sm text-gray-600">Access to top universities and programs</p>
            </div>
            <div className="bg-blue-50 p-6 rounded-lg text-center hover:shadow-lg transition">
              <Target className="w-12 h-12 text-blue-700 mx-auto mb-3" />
              <h3 className="font-bold text-gray-900 mb-2">Career Focused</h3>
              <p className="text-sm text-gray-600">Programs aligned with industry needs</p>
            </div>
            <div className="bg-blue-50 p-6 rounded-lg text-center hover:shadow-lg transition">
              <Users className="w-12 h-12 text-blue-700 mx-auto mb-3" />
              <h3 className="font-bold text-gray-900 mb-2">Expert Guidance</h3>
              <p className="text-sm text-gray-600">Personalized counseling support</p>
            </div>
            <div className="bg-blue-50 p-6 rounded-lg text-center hover:shadow-lg transition">
              <Award className="w-12 h-12 text-blue-700 mx-auto mb-3" />
              <h3 className="font-bold text-gray-900 mb-2">Trusted Partner</h3>
              <p className="text-sm text-gray-600">Recognized for reliability and transparency</p>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-blue-700 to-blue-900 text-white p-8 rounded-lg">
          <h3 className="text-2xl font-bold mb-4 text-center">Our Vision</h3>
          <p className="text-center text-lg leading-relaxed max-w-3xl mx-auto">
            At Sree Balajee Scholars Hub, we believe education is the foundation of success. Our commitment, professionalism, and transparent process have earned us recognition as a reliable educational partner for students across India. We continue to grow with a vision to empower students and build strong academic futures.
          </p>
        </div>
      </div>
    </section>
  );
}
