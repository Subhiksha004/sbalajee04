export function Footer() {
  return (
    <footer id="contact" className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-3 gap-8">
          {/* About */}
          <div>
            <h3 className="text-xl font-bold mb-4">Sree Balajee Scholars Hub</h3>
            <p className="text-gray-400 leading-relaxed">
              A trusted education consultancy dedicated to guiding students towards the right academic and career opportunities.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => document.getElementById("about")?.scrollIntoView({ behavior: "smooth" })}
                  className="text-gray-400 hover:text-white transition"
                >
                  About Us
                </button>
              </li>
              <li>
                <button
                  onClick={() => document.getElementById("programs")?.scrollIntoView({ behavior: "smooth" })}
                  className="text-gray-400 hover:text-white transition"
                >
                  Programs
                </button>
              </li>
              <li>
                <button
                  onClick={() => document.getElementById("process")?.scrollIntoView({ behavior: "smooth" })}
                  className="text-gray-400 hover:text-white transition"
                >
                  Work Process
                </button>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-xl font-bold mb-4">Contact Us</h3>
            <div className="space-y-3 text-gray-400">
              <p>📞 +91 98765 43210</p>
              <p>📧 info@sreebalajee.com</p>
              <p>📍 Sree Balajee Scholars, Inkollu, Bapatla, Andhra Pradesh - 523167</p>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Sree Balajee Scholars Hub. All rights reserved.</p>
          <p className="mt-2 text-sm">Established under Sree Balaji Educational Charitable Trust</p>
        </div>
      </div>
    </footer>
  );
}
