import { GraduationCap, BookOpenCheck, FileSpreadsheet, Briefcase, Award } from "lucide-react";

export function ProgramsSection() {
  const programs = [
    {
      icon: GraduationCap,
      title: "Undergraduate Programs",
      description: "Bachelor's degree programs across various disciplines including Arts, Science, Commerce, and more.",
      examples: ["BA", "BSc", "BCom", "BBA", "BCA"]
    },
    {
      icon: BookOpenCheck,
      title: "Postgraduate Programs",
      description: "Advanced master's programs for specialized knowledge and career advancement.",
      examples: ["MA", "MSc", "MCom", "MBA", "MCA"]
    },
    {
      icon: FileSpreadsheet,
      title: "Diploma Programs",
      description: "Professional diploma courses for skill development and career-ready education.",
      examples: ["PG Diploma", "Advanced Diploma", "Vocational Diploma"]
    },
    {
      icon: Briefcase,
      title: "Technical Programs",
      description: "Industry-focused technical programs for engineering and technology careers.",
      examples: ["Engineering", "Technology", "Computer Applications"]
    },
    {
      icon: Award,
      title: "Professional Programs",
      description: "Specialized professional courses for career-specific education and certification.",
      examples: ["Management", "Finance", "Healthcare", "Education"]
    }
  ];

  return (
    <section id="programs" className="py-16 sm:py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Our Programs</h2>
          <div className="w-24 h-1 bg-blue-700 mx-auto mb-6"></div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Explore a wide range of academic programs offered in collaboration with renowned universities
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {programs.map((program, index) => (
            <div
              key={index}
              className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition duration-300 border-t-4 border-blue-700"
            >
              <program.icon className="w-12 h-12 text-blue-700 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-3">{program.title}</h3>
              <p className="text-gray-600 mb-4 leading-relaxed">{program.description}</p>
              <div className="flex flex-wrap gap-2">
                {program.examples.map((example, idx) => (
                  <span
                    key={idx}
                    className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm"
                  >
                    {example}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* University Partnership */}
        <div className="bg-white p-8 rounded-lg shadow-lg border-2 border-blue-200">
          <div className="text-center">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">University Partnership</h3>
            <div className="inline-block bg-blue-700 text-white px-8 py-4 rounded-lg">
              <h4 className="text-2xl font-bold">Nagarjuna University</h4>
              <p className="text-blue-100 mt-2">Recognized & Accredited Institution</p>
            </div>
            <p className="mt-6 text-gray-600 max-w-2xl mx-auto leading-relaxed">
              We proudly partner with Nagarjuna University to offer quality education programs. 
              Our strong collaboration ensures students receive recognized degrees and excellent academic support.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
