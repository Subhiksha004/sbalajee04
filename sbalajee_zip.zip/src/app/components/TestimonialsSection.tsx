import { Quote } from "lucide-react";

export function TestimonialsSection() {
  const testimonials = [
    {
      name: "Rajesh Kumar",
      course: "MBA Graduate",
      text: "Sree Balajee Scholars Hub made my admission process incredibly smooth. Their guidance and support were exceptional throughout my journey.",
      rating: 5
    },
    {
      name: "Priya Sharma",
      course: "BCA Student",
      text: "The counseling I received helped me choose the perfect course. The team was always available to answer my questions and concerns.",
      rating: 5
    },
    {
      name: "Arun Reddy",
      course: "MSc Graduate",
      text: "Excellent service from start to finish. They handled all my documents professionally and kept me updated at every step.",
      rating: 5
    }
  ];

  return (
    <section className="py-16 sm:py-20 bg-gradient-to-br from-blue-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Student Success Stories</h2>
          <div className="w-24 h-1 bg-blue-700 mx-auto mb-6"></div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Hear from our satisfied students about their experience with us
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition duration-300 relative"
            >
              <Quote className="w-10 h-10 text-blue-700 opacity-20 absolute top-4 right-4" />
              <div className="mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <span key={i} className="text-yellow-400 text-xl">★</span>
                ))}
              </div>
              <p className="text-gray-700 mb-4 italic leading-relaxed">"{testimonial.text}"</p>
              <div className="border-t pt-4">
                <p className="font-bold text-gray-900">{testimonial.name}</p>
                <p className="text-sm text-gray-600">{testimonial.course}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
