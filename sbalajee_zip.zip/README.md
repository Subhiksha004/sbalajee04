
  # Website Wireframe

  This is a code bundle for Website Wireframe. The original project is available at https://www.figma.com/design/aV4YpNsBiUNLA8BsjrLvfH/Website-Wireframe.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  